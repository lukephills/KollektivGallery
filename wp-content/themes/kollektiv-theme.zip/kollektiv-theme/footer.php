<?php

?>

<div id="footer">
	<div class="container">
         <p>Please contact: Gallery Creative Director - Sophie Giblin
         	<br/>
         	<a href="mailto:sophie@kollektivgallery.com">sophie@kollektivgallery.com</a>
         </p>

         <p>© <?php echo date('Y'); ?> KollektivGallery.com</p>
	</div>
</div>

<?php wp_footer(); ?>

</body>
</html>
