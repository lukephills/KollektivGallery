$(document).ready(function(){
	// Cache the Window object
	$window = $(window);
   
   // PARALLAX IMAGES

   $('section[data-type="background"]').each(function(){
     var $bgobj = $(this); // assigning the object
                    
      	$(window).scroll(function() {
	                    
			// Scroll the background at var speed
			// the yPos is a negative value because we're scrolling it UP!								
			var yPos = -($window.scrollTop() / $bgobj.data('speed')); 
			
			// Put together our final background position
			var coords = '50% '+ yPos + 'px';

			// Move the background
			$bgobj.css({ backgroundPosition: coords });
			
		}); // window scroll Ends

	});	

   	$(window).on('scroll',function() {
    	
    	var scrolltop = $(this).scrollTop();
 
    	if(scrolltop >= 55) {
      		$('#navigation').fadeOut(275);
    	}	
    	else if(scrolltop <= 55) {     			
      		$('#navigation').fadeIn(400);      		
    }
    	
  });

   	// LOGO ANIMATION

    var logoCount = 0; //logo rollovers
    
   $(".logo").mouseenter(function() {
        
        var $this = $('.logo_o')
    	
    	if(!$this.hasClass('spin')){
        	$this.addClass('spin');
    	}
    	else{
       		$this.removeClass('spin');
        	setTimeout(function(){
            $this.addClass('spin');
        },20);
    }
    }); 

	$(".logo").mouseenter(function() {
				
		    $(".logo_g").filter(':not(:animated)').animate({ marginTop: "20px", opacity: 0.3 }, 400);
		    $(".logo_g").animate({ marginTop: "40px", opacity: 1 }, 500);
		    $(".logo_k").filter(':not(:animated)').animate({ marginLeft: "120px", opacity: 0.5 }, 300);
		    $(".logo_k").filter(':not(:animated)').animate({ marginLeft: "0px"}, 600);
		    $(".logo_k").animate({ marginLeft: "40px", opacity: 1 }, 600);
		    $(".logo_o").filter(':not(:animated)').animate({ marginLeft: "40px"}, 600);
		    $(".logo_a").filter(':not(:animated)').animate({ opacity: 0.3 }, 200);
		    $(".logo_a").animate({ opacity: 1 }, 600);

		    logoCount++;	   
	});

	if (logoCount > 5){
		//do something
	}






}); 
/* 
 * Create HTML5 elements for IE's sake
 */

document.createElement("article");
document.createElement("section");