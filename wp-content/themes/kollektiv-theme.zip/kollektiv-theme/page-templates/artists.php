<?php get_header(); ?>


// Artists images

<section class="artist-images">	
	<div class="4columns">

		<?php
			query_posts(array('category_name' => 'Featured', 'posts_per_page' => 20));
			if(have_posts()) : while(have_posts()) : the_post();
		?>

			<div class="main-artist-image">
				<?php the_post_thumbnail('main-artist-image'); ?>
				<div class="caption">
					<a href="#" class="artist-name"><?php the_title(); ?></a>
					<?php the_excerpt(); ?>
				</div>
			</div>

		<?php
			endwhile;
			endif:
			wp_reset_query();
		?>

	</div>
</section>
	
<?php get_footer(); ?>