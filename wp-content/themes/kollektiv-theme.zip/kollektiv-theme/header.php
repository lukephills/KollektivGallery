<!DOCTYPE html>
<html>
<head>

	<title>
		<?php 
			wp_title( '|', true, 'right' ); 
			bloginfo( 'name' );
		?>
	</title>

	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<meta type="viewport" content="width=device-width, initial-scale=1">

	<link rel="shortcut icon" href="<?php bloginfo( 'template_url' );?>/assets/favicon.ico">
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' );?>/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' );?>/css/bootstrap-responsive.min.css">
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' );?>/css/styles.css">



  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
  <script type="text/javascript" language="javascript" charset="utf-8" src="<?php bloginfo( 'template_url' );?>/js/bootstrap.min.js"></script>
  <script type="text/javascript" language="javascript" charset="utf-8" src="<?php bloginfo( 'template_url' );?>/js/scripts.js"></script>
	
	<?php wp_head(); ?>
	
</head>

<body <?php body_class(); ?>>
	<div class="container">
		<header>
			<nav id="navigation">
		      	
		      <a href="<?php echo get_option ('home');?>">
			      <div class="logo">
			        <div class="logo_k letter"></div>
			        <div class="logo_o letter"></div>
			        <div class="logo_g letter"></div>
			        <div class="logo_a letter"></div>
			      </div>
		      </a>

		      	<?php wp_nav_menu( array( 
		      		'container' => false,
		      		'menu_class' => 'navlinks',
		      		'theme_location' => 'primary'
		      	) ); ?>

		            

		           
		    </nav>
		</header>
	</div>
