<?php get_header(); ?>

<section id="heading" class="whitebk">
      <div class="container">

	<?php while ( have_posts() ) : the_post(); ?>
	
		<?php get_template_part( 'content', 'page' ); ?>
		
	<?php endwhile; ?>

</div>
    </section>


    <section id="big-image3" data-type="background" data-speed="10">     
    </section>

<?php get_sidebar(); ?>
<?php get_footer(); ?>