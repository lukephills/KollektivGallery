<?php


// Create Nav Menu

if (function_exists('register_nav_menus')) {
	register_nav_menus (array('primary' => 'Header Navigation') );
}


// Switching on support for post thumbnails/lead images

if (function_exists('add_theme_support')) {
	add_theme_support('post-thumbnails');
}

if (function_exists('add_image_size')) {
	add_image_size('featured', 400, 250, true); //name of image, w, h, crop?
	add_image_size('main-artist-image', 400, 350, true);
	add_image_size('post-thumb', 200, 125, true);
	add_image_size('small-square', 100, 100, true);
}

function create_post_type(){
	register_post_type('kollektiv_artists', // slug - Called kollektiv_artists to avoid it interference
		array('labels' => 
			array(
				'name' => __('Artists'),
				'singular_name' => __('Artist') // "__" Allows wordpress to translate this word to localised setting
			),
			'public' => true, 
			'menu_postiion' => 5, // This is where it shows up in admin menu (5=below posts, 10=below media, 15=below links, etc...)
			'rewrite' => array('slug' => 'artists') //changing name from 'kollektiv_artists' to 'artists'
		)
	);  
}

add_action ('init', 'create_post_type');


/**
 * Sets up theme defaults and registers the various WordPress features that
 * the Migration theme supports.
 *
 * @uses add_editor_style() To add a Visual Editor stylesheet.
 * @uses add_theme_support() To add support for post thumbnails
 * @uses register_nav_menu() To add support for navigation menus.
 * @uses set_post_thumbnail_size() To set a custom post thumbnail size.
 *
 */
function migration_setup() {

	// This theme styles the visual editor with editor-style.css to give it some niceties.
	add_editor_style();

	// This theme uses wp_nav_menu() in one location.
	register_nav_menu( 'primary', __( 'Primary Menu', 'migration' ) );

	// This theme uses a custom image size for featured images, displayed on "standard" posts.
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 500, 9999 ); // Unlimited height, soft crop
}
add_action( 'after_setup_theme', 'migration_setup' );


/**
 * Enqueues scripts and styles for front-end.
 */
function migration_scripts_styles() {
	global $wp_styles;

	/*
	 * Loads our main stylesheet.
	 */
	wp_enqueue_style( 'migration-style', get_stylesheet_uri() );

	/*
	 * Optional: Loads the Internet Explorer specific stylesheet.
	 */
	//wp_enqueue_style( 'migration-ie', get_template_directory_uri() . '/css/ie.css', array( 'migration-style' ), '20121010' );
	//$wp_styles->add_data( 'migration-ie', 'conditional', 'lt IE 9' );
}
add_action( 'wp_enqueue_scripts', 'migration_scripts_styles' );
