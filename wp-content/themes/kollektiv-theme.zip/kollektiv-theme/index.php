<?php get_header(); ?>


<section id="home-container" class="whitebk">
      <div class="container text-center">
      
    
    	<div class="row top-row">

  			<div class="logo-kickstarter col-xs-12 .col-sm-5 col-md-5 col-md-offset-2">
				<img class="logo_image" src="<?php bloginfo( 'template_url' );?>/images/logo.png"/>
			</div>
			<div class="col-xs-12 .col-sm-5 col-md-5">
				 <iframe class="kickstarter_widget" frameborder="0" height="380" scrolling="no" src="http://www.kickstarter.com/projects/kollektivgallery/kollektivs-first-ever-gallery/widget/card.html" width="220"></iframe>
			</div>
		</div>
       
   
        <h4>We’re invading Brighton’s empty high street shops with the best, emerging, studying and recently graduated illustrators, fine artists and experimental visual explorers.</h4>
        
        <h2><a href="http://www.kickstarter.com/projects/kollektivgallery/kollektivs-first-ever-gallery">DONATE</a></h2>
      </div>
    </section>



    <section id="big-image" data-type="background" data-speed="13">     
    </section>


    <section class="bluebk">

<div class="row">
  <div class="col-xs-12 .col-sm-2 col-md-2">
  </div>
  <div class="col-xs-12 .col-sm-5 col-md-5 text-center">
    <h4>Kollektiv is a Pop Up gallery giving workshops about entrepreneurialism to emerging artists. Watch this space for our next project.</h4>
<br>
    <h5>Support our newest pop up <a href="http://www.wearepopup.com/p/kollektiv-gallery/">project</a>.</h5> 
  </div>
  <div class="col-xs-12 .col-sm-5 col-md-5">

    <img src="<?php bloginfo( 'template_url' );?>/images/turqPoster.jpg" class="turqPoster" />

  </div>

</div>


    </section>



		
<?php get_sidebar(); ?>
<?php get_footer(); ?>